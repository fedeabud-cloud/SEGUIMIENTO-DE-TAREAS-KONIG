import React from "react";
import AsanaDashboardWithReports from "./AsanaDashboardWithReports";

export default function App() {
  return <AsanaDashboardWithReports />;
}