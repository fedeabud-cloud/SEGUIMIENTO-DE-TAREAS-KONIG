# 🗂 Seguimiento de Tareas

Aplicación web interactiva estilo **Asana**, desarrollada en **React + Tailwind + Recharts**, para gestionar tareas, prioridades y reportes con posibilidad de exportar datos a **PDF** y **Excel**.

---

## 🚀 Funcionalidades principales

✅ Gestión de tareas con prioridad, estado y responsable  
✅ Pestañas para “Tareas” y “Reportes”  
✅ Gráfico de barras con distribución de estados  
✅ Botón **Exportar ▾** para generar:
   - Archivo `.xlsx` (Excel)
   - Archivo `.txt` (reporte PDF textual)
✅ Interfaz limpia estilo Asana  
✅ 100% funcional en el navegador (sin instalación local)

---

## 🧩 Estructura de archivos

```
seguimiento-de-tareas/
│
├── src/
│   ├── App.js
│   ├── AsanaDashboardWithReports.jsx
│   ├── index.css
│   └── index.js
│
├── index.html
├── tailwind.config.js
├── package.json
└── README.md
```

---

## 💻 Ejecución en StackBlitz

1. Subí este repositorio a GitHub.  
2. Abrí este enlace para ejecutarlo directamente en StackBlitz:  
   👉 **[Abrir en StackBlitz](https://stackblitz.com/github/fedeabud-cloud/seguimiento-de-tareas)**  
3. Esperá unos segundos — el entorno se cargará automáticamente.  

---

## 🌐 Despliegue en Vercel

1. Entrá a [https://vercel.com/new](https://vercel.com/new)  
2. Iniciá sesión con GitHub y elegí el repositorio **seguimiento-de-tareas**.  
3. Vercel detectará automáticamente el proyecto Vite + React.  
4. Configurá:
   - **Framework Preset:** `Vite`
   - **Build Command:** `vite build`
   - **Output Directory:** `dist`
5. Clic en **Deploy** 🚀  

Tu app quedará publicada en una URL como:  
`https://seguimiento-de-tareas.vercel.app`

---

## 🧠 Tecnologías utilizadas

- **React 18**  
- **Tailwind CSS 3**  
- **Recharts** (visualizaciones)  
- **xlsx** + **file-saver** (exportación de datos)  

---

## 📄 Licencia

Proyecto libre de uso educativo y empresarial bajo licencia MIT.  
Desarrollado por [fedeabud-cloud](https://github.com/fedeabud-cloud)
